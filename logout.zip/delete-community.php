<?php
include ('connect.php');

// Check if the community number (cn) is set in the URL
if (isset($_GET['cn'])) {
    // Sanitize the input to prevent SQL injection
    $community_no = intval($_GET['cn']);

    // Prepare the SQL DELETE statement
    $sql = "DELETE FROM community WHERE community_no = $community_no";

    // Execute the query
    if (mysqli_query($con, $sql)) {
        // If successful, display a popup and then redirect
        echo '<script>
                alert("Record deleted successfully.");
                window.location.href = "admin-panel.php";
              </script>';
    } else {
        // If there's an error, display it
        echo "Error deleting record: " . mysqli_error($con);
    }

    // Close the database connection
    mysqli_close($con);
} else {
    echo "Invalid request.";
}
?>
