
<?php
$con = mysqli_connect("localhost", "root", "", "shikshashastra3");
?>
